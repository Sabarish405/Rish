package com.wipro.bank.exception;

public class BankValidationException {

}

package com.wipro.bank.service;

public class BankService {

}

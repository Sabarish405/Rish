package com.wipro.bank.main;

public class MainClass {

}

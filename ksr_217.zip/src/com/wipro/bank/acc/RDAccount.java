package com.wipro.bank.acc;

public class RDAccount {

}
